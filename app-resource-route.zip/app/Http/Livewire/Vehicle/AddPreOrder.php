<?php

namespace App\Http\Livewire\Vehicle;

use App\User;
use Livewire\Component;
use App\VehiclePreOrder;
use App\VehicleProduct;

class AddPreOrder extends Component
{
    public $customer_id, $pre_order_recived_by, $order_date, $vehicle_category, $product_id, $preferred_year, $preferred_color, $preferred_millage, $preferred_grade, $other_requirements, $budget, $expected_delivery_date, $booking_amount, $additional_information;
    protected $rules = [
        'vehicle_manufacture_id' => 'nullable',
        'vehicle_model_id' => 'nullable',
    ];
    public function render()
    {
        return view('livewire.vehicle.add-pre-order', [
            'customers' => User::all(),
            'recived_users' => User::all(),
            'products' => VehicleProduct::when($this->vehicle_category, function ($query) {
                $query->where('product_category', 'LIKE', '%' . $this->vehicle_category . '%');
            })->get()
        ]);
    }
    public function store()
    {
        VehiclePreOrder::create([
            'customer_id' => $this->customer_id,
            'pre_order_recived_by' => $this->pre_order_recived_by,
            'order_date' => $this->order_date,
            'vehicle_category' => $this->vehicle_category,
            'product_id' => $this->product_id,
            'preferred_year' => $this->preferred_year,
            'preferred_color' => $this->preferred_color,
            'preferred_millage' => $this->preferred_millage,
            'preferred_grade' => $this->preferred_grade,
            'other_requirements' => $this->other_requirements,
            'budget' => $this->budget,
            'expected_delivery_date' => $this->expected_delivery_date,
            'booking_amount' => $this->booking_amount,
            'additional_information' => $this->additional_information,
            'created_by' => auth()->user()->id,
        ]);
        $this->dispatchBrowserEvent('success', ['msg' => 'Pre Order Added Successfully']);
        return redirect()->route('vehicle.pre.order.list');
    }
}
