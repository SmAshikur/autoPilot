<?php

namespace App\Http\Livewire\Vehicle;

use App\User;
use App\TyreSize;
use App\VehicleModel;
use App\ExteriorColor;
use App\InteriorColor;
use App\LocalPurchase;
use App\VehicleProduct;
use Livewire\Component;
use App\VehiclePreOrder;
use App\PackageTrimVariant;
use App\VehicleManufacture;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\DB;

class LocalPurchaseList extends Component
{
    use WithFileUploads;
    public $size, $color, $color_code, $name,
        $vehicle_model_id,
        $vehicle_manufacture_id, $vehicle_category_search, $customer_search, $purchase_id, $purchase_date, $purchase_form, $supplier, $invoice_number, $purchase_mode, $remarks, $source_of_product, $vehicle_type, $pre_order_id, $vehicle_condition, $vehicle_id, $packge_trim_id, $chassis_id, $engine_id, $year_of_manufacture, $exterior_color_id, $interior_color_id, $millage, $action_grade, $registration_no, $registration_year, $seating_capacity, $tyre_size_id, $tracking_code, $vehicle_image, $vehicle_description, $pricing_information, $vehicle_price, $total_estimated_cost, $total_cost, $margin, $sale_price, $vehicle_location_id, $cost_type = [], $amount = [], $count = 1;
    function preOrderSelected()
    {
        $pre_order = VehiclePreOrder::find($this->pre_order_id);
        $this->vehicle_type = $pre_order->vehicle_category;
        $this->vehicle_id = $pre_order->product_id;
        $this->millage = $pre_order->preferred_millage;
        $this->action_grade = $pre_order->preferred_year;
    }
    public $seating_capacities = [
        2, 4, 5, 6, 7, 8, 9, 10, 11, 12,
        13, 14, 15, 16, 17, 18, 19, 20, 21, 22,
        23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
        33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
        43, 44, 45, 46, 47, 48, 49, 50, 51, 52,
        53, 54, 55, 56, 57, 58, 59, 60
    ];
    protected $rules = [
        'purchase_date' => 'required',
        'purchase_form' => 'required',
        'supplier' => 'required',
        'invoice_number' => 'required',
        'purchase_mode' => 'required',
        'source_of_product' => 'required',
        'vehicle_type' => 'required',
        'vehicle_condition' => 'required',
        'vehicle_id' => 'required',
        'chassis_id' => 'required',
        'year_of_manufacture' => 'required',
    ];
    public function mount()
    {
        $this->source_of_product = 'Pre Order';
        $this->vehicle_type = 'Passenger';
        $this->vehicle_condition = 'Recondition';
        $this->dispatchBrowserEvent('show-modal', ['id' => 'pre-order-modal']);
    }
    public function render()
    {
        return view('livewire.vehicle.local-purchase-list', [
            'purchases' => LocalPurchase::when($this->vehicle_category_search, function ($query) {
                $query->where('vehicle_type', $this->vehicle_category_search);
            })
                ->when($this->customer_search, function ($query) {
                    $query->where('supplier', $this->customer_search);
                })
                ->paginate(10),
            'customers' => User::all(),
            'recived_users' => User::all(),
            'suppliers' => User::all(),
            'products' => VehicleProduct::when($this->vehicle_type, function ($query) {
                $query->where('product_category', 'LIKE', '%' . $this->vehicle_type . '%');
            })->get(),
            'packages' => PackageTrimVariant::all(),
            'exterior_colors' => ExteriorColor::all(),
            'interior_colors' => InteriorColor::all(),
            'tyre_sizes' => TyreSize::all(),
            'pre_orders' => VehiclePreOrder::get(),
            'year_of_manufacture' => VehiclePreOrder::get(),
            'vehicle_manufactures' => VehicleManufacture::all(),
            'models' => VehicleModel::when($this->vehicle_manufacture_id, function ($query) {
                $query->where('vehicle_manufacture_id', $this->vehicle_manufacture_id);
            })->get()
        ]);
    }
    public function edit($id)
    {
        $res = LocalPurchase::find($id);
        if (!blank($res)) {
            $this->count = count($res->pricing_information);
            $this->cost_type = array_column($res->pricing_information, 'cost_type');
            $this->amount = array_column($res->pricing_information, 'amount');
            $this->purchase_id = $id;
            $this->purchase_date = $res->purchase_date ?? '';
            $this->purchase_form = $res->purchase_form ?? '';
            $this->supplier = $res->supplier ?? '';
            $this->invoice_number = $res->invoice_number ?? '';
            $this->purchase_mode = $res->purchase_mode ?? '';
            $this->remarks = $res->remarks ?? '';
            $this->source_of_product = $res->source_of_product ?? '';
            $this->vehicle_type = $res->vehicle_type ?? '';
            $this->vehicle_condition = $res->vehicle_condition ?? '';
            $this->vehicle_id = $res->vehicle_id ?? '';
            $this->packge_trim_id = $res->packge_trim_id ?? '';
            $this->chassis_id = $res->chassis_id ?? '';
            $this->engine_id = $res->engine_id ?? '';
            $this->year_of_manufacture = $res->year_of_manufacture ?? '';
            $this->exterior_color_id = $res->exterior_color_id ?? '';
            $this->interior_color_id = $res->interior_color_id ?? '';
            $this->millage = $res->millage ?? '';
            $this->action_grade = $res->action_grade ?? '';
            $this->seating_capacity = $res->seating_capacity ?? '';
            $this->tyre_size_id = $res->tyre_size_id ?? '';
            $this->tracking_code = $res->tracking_code ?? '';
            $this->registration_no = $res->registration_no;
            $this->registration_year = $res->registration_year;
            $this->vehicle_image = $res->vehicle_image ?? '';
            $this->vehicle_description = $res->vehicle_description ?? '';
            $this->pricing_information = $res->pricing_information ?? '';
            $this->vehicle_price = $res->vehicle_price ?? '';
            $this->total_estimated_cost = $res->total_estimated_cost ?? '';
            $this->total_cost = $res->total_cost ?? '';
            $this->margin = $res->margin ?? '';
            $this->sale_price = $res->sale_price ?? '';
            $this->vehicle_location_id = $res->vehicle_location_id ?? '';
            $this->dispatchBrowserEvent('show-modal', ['id' => 'update-purchase-modal']);
        }
    }
    public function updated($propertyName)
    {
        if ($propertyName == 'source_of_product') {
            if ($this->source_of_product == 'Pre Order') {
                $this->dispatchBrowserEvent('show-modal', ['id' => 'pre-order-modal']);
            } else {
                $this->dispatchBrowserEvent('hide-modal', ['id' => 'pre-order-modal']);
            }
        }
        //Pre Order
        if ($propertyName == 'pre_order_id') {
            $this->preOrderSelected();
        }
        //Vehicle Price
        if ($propertyName == 'vehicle_price') {
            $this->total_cost = $this->total_estimated_cost + $this->vehicle_price;
        }
        //Vehicle Price
        // if ($propertyName == 'total_estimated_cost') {
        //     dd($this->total_estimated_cost);
        //     // $this->total_cost = $this->total_estimated_cost + $this->vehicle_price;
        // }
    }

    function generateInvoiceNumber($prefix = 'INV')
    {
        // Get the current date in the format YYYYMMDD.
        $date = now()->format('Ymd');

        // Get the latest invoice number from the database.
        $latestInvoice = DB::table('local_purchases')
            ->select('invoice_number')
            ->orderBy('id', 'desc')
            ->first();

        if ($latestInvoice) {
            // Extract the sequential number from the latest invoice number.
            $lastSeqNumber = substr($latestInvoice->invoice_number, -4);
            $newSeqNumber = str_pad($lastSeqNumber + 1, 4, '0', STR_PAD_LEFT);
        } else {
            // If no previous invoice, start with 0001.
            $newSeqNumber = '0001';
        }

        // Combine the prefix, date, and sequential number to create the new invoice number.
        $invoiceNumber = $prefix . $date . $newSeqNumber;

        $this->invoice_number = $invoiceNumber;
    }
    public function addRow()
    {
        $this->total_estimated_cost = 0;
        $new_count = 1;
        for ($i = 0; $i < $this->count; $i++) {
            if (!isset($this->cost_type[$i]) || !isset($this->amount[$i])) {
                $this->dispatchBrowserEvent('error', ['msg' => 'Please enter cost type or amount data']);
            } else {
                $this->total_estimated_cost += $this->amount[$i];
                $new_count++;
            }
        }
        $this->total_cost = $this->total_estimated_cost + $this->vehicle_price;
        $this->count = $new_count;
    }
    public function update()
    {
        $purchase = LocalPurchase::find($this->purchase_id);
        $this->validate();
        if ($this->vehicle_image) {
            $vehicle_image = $this->vehicle_image->store('purchase', 'vehicle');
        } else {
            $vehicle_image = $purchase->vehicle_image;
        }
        if ($this->count > 1) {

            for ($i = 0; $i < ($this->count - 1); $i++) {
                $jsonData[] = [
                    'cost_type' => $this->cost_type[$i],
                    'amount' => $this->amount[$i],
                ];
            }
        }

        $purchase->update([
            'purchase_date' => $this->purchase_date,
            'purchase_form' => $this->purchase_form,
            'supplier' => $this->supplier,
            'invoice_number' => $this->invoice_number,
            'purchase_mode' => $this->purchase_mode,
            'remarks' => $this->remarks,
            'source_of_product' => $this->source_of_product,
            'vehicle_type' => $this->vehicle_type,
            'vehicle_condition' => $this->vehicle_condition,
            'vehicle_id' => $this->vehicle_id,
            'packge_trim_id' => $this->packge_trim_id,
            'chassis_id' => $this->chassis_id,
            'engine_id' => $this->engine_id,
            'year_of_manufacture' => $this->year_of_manufacture,
            'exterior_color_id' => $this->exterior_color_id,
            'interior_color_id' => $this->interior_color_id,
            'millage' => $this->millage,
            'action_grade' => $this->action_grade,
            'seating_capacity' => $this->seating_capacity,
            'tyre_size_id' => $this->tyre_size_id,
            'tracking_code' => $this->tracking_code,
            'registration_no' => $this->registration_no,
            'registration_year' => $this->registration_year,
            'vehicle_image' => $vehicle_image,
            'vehicle_description' => $this->vehicle_description,
            'pricing_information' => $this->pricing_information,
            'vehicle_price' => $this->vehicle_price,
            'total_estimated_cost' => $this->total_estimated_cost,
            'total_cost' => $this->total_cost,
            'margin' => $this->margin,
            'sale_price' => $this->sale_price,
            'vehicle_location_id' => $this->vehicle_location_id,
            'created_by' => auth()->user()->id,
        ]);
        $this->dispatchBrowserEvent('hide-modal', ['id' => 'update-purchase-modal']);

        $this->dispatchBrowserEvent('success', ['msg' => 'Local Purchase Updated Successfully']);
    }
    public function delete($id)
    {
        $res = LocalPurchase::find($id);
        $res->delete();
        $this->dispatchBrowserEvent('success', ['msg' => 'Local Purchase Deleted Successfully']);
    }
    //Package Trim
    public function addPackageTrim()
    {
        $this->dispatchBrowserEvent('show-modal', ['id' => 'package-trim-modal']);
    }
    public function storePackageTrim()
    {
        PackageTrimVariant::create([
            'name' => $this->name,
            'vehicle_model_id' => $this->vehicle_model_id,
            'vehicle_manufacture_id' => $this->vehicle_manufacture_id,
            'created_by' => auth()->user()->id
        ]);
        $this->dispatchBrowserEvent('success', ['msg' => 'Package/Trim Added Successfully']);
        $this->dispatchBrowserEvent('hide-modal', ['id' => 'package-trim-modal']);
    }
    //Exterior Color
    public function addExteriorColor()
    {
        $this->dispatchBrowserEvent('show-modal', ['id' => 'exterior-color-modal']);
    }
    public function storeExteriorColor()
    {
        ExteriorColor::create([
            'color' => $this->color,
            'color_code' => $this->color_code,
            'created_by' => auth()->user()->id
        ]);
        $this->dispatchBrowserEvent('success', ['msg' => 'Exterior Color Added Successfully']);
        $this->dispatchBrowserEvent('hide-modal', ['id' => 'exterior-color-modal']);
    }
    //Exterior Color
    public function addTyreSize()
    {
        $this->dispatchBrowserEvent('show-modal', ['id' => 'tyre-size-modal']);
    }
    public function storeTyreSize()
    {
        TyreSize::create([
            'size' => $this->size,
            'created_by' => auth()->user()->id
        ]);
        $this->dispatchBrowserEvent('success', ['msg' => 'Tyre Added Successfully']);
        $this->dispatchBrowserEvent('hide-modal', ['id' => 'tyre-size-modal']);
    }
}
