<?php

namespace App\Http\Livewire\Vehicle;

use App\User;
use App\TyreSize;
use App\VehicleProduct;
use Livewire\Component;
use App\VehiclePreOrder;
use Livewire\WithPagination;

class PreOrderList extends Component
{
    use WithPagination;
    public $order_id, $vehicle_category_search, $status_search, $recived_by_search, $customer_search, $vehicle_name_search, $customer_id, $pre_order_recived_by, $order_date, $vehicle_category, $product_id, $preferred_year, $preferred_color, $preferred_millage, $preferred_grade, $other_requirements, $budget, $expected_delivery_date, $booking_amount, $additional_information;
    protected $rules = [
        'vehicle_manufacture_id' => 'nullable',
        'vehicle_model_id' => 'nullable',
    ];
    protected $queryString = [
        'vehicle_category_search' => ['except' => ''],
        'status_search' => ['except' => ''],
        'recived_by_search' => ['except' => ''],
        'customer_search' => ['except' => ''],
        'vehicle_name_search' => ['except' => ''],
    ];
    public function render()
    {
        return view('livewire.vehicle.pre-order-list', [
            'orders' => VehiclePreOrder::when($this->vehicle_category_search, function ($query) {
                $query->where('vehicle_category', $this->vehicle_category_search);
            })
                ->when($this->recived_by_search, function ($query) {
                    $query->where('pre_order_recived_by', $this->recived_by_search);
                })
                ->when($this->customer_search, function ($query) {
                    $query->where('customer_id', $this->customer_search);
                })
                ->when($this->vehicle_name_search, function ($query) {
                    $query->where('product_id', $this->vehicle_name_search);
                })
                ->paginate(10),
            'customers' => User::all(),
            'recived_users' => User::all(),
            'products' => VehicleProduct::when($this->vehicle_category, function ($query) {
                $query->where('product_category', 'LIKE', '%' . $this->vehicle_category . '%');
            })->get()
        ]);
    }
    public function edit($id)
    {
        $res = VehiclePreOrder::find($id);
        if (!blank($res)) {
            $this->order_id = $id;
            $this->customer_id = $res->customer_id;
            $this->pre_order_recived_by = $res->pre_order_recived_by;
            $this->order_date = $res->order_date;
            $this->vehicle_category = $res->vehicle_category;
            $this->product_id = $res->product_id;
            $this->preferred_year = $res->preferred_year;
            $this->preferred_color = $res->preferred_color;
            $this->preferred_millage = $res->preferred_millage;
            $this->preferred_grade = $res->preferred_grade;
            $this->other_requirements = $res->other_requirements;
            $this->budget = $res->budget;
            $this->expected_delivery_date = $res->expected_delivery_date;
            $this->booking_amount = $res->booking_amount;
            $this->additional_information = $res->additional_information;
        }
        $this->dispatchBrowserEvent('show-modal', ['id' => 'update-modal']);
    }
    public function update()
    {
        $res = VehiclePreOrder::find($this->order_id);
        $res->update([
            'customer_id' => $this->customer_id,
            'pre_order_recived_by' => $this->pre_order_recived_by,
            'order_date' => $this->order_date,
            'vehicle_category' => $this->vehicle_category,
            'product_id' => $this->product_id,
            'preferred_year' => $this->preferred_year,
            'preferred_color' => $this->preferred_color,
            'preferred_millage' => $this->preferred_millage,
            'preferred_grade' => $this->preferred_grade,
            'other_requirements' => $this->other_requirements,
            'budget' => $this->budget,
            'expected_delivery_date' => $this->expected_delivery_date,
            'booking_amount' => $this->booking_amount,
            'additional_information' => $this->additional_information,
        ]);
        $this->reset();
        $this->dispatchBrowserEvent('hide-modal', ['id' => 'update-modal']);

        $this->dispatchBrowserEvent('success', ['msg' => 'Pre Order Updated Successfully']);
    }
    public function delete($id)
    {
        $res = VehiclePreOrder::find($id);
        $res->delete();
        $this->dispatchBrowserEvent('success', ['msg' => 'Pre Order Deleted Successfully']);
    }
}
