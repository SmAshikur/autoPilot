<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InteriorColor extends Model
{
    use HasFactory;
    protected $fillable = [
        'color',
        'color_code',
        'created_by',
    ];
}
