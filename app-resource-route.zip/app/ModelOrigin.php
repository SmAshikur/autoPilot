<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelOrigin extends Model
{
    use HasFactory;
    protected $fillable = ['model'];
}
