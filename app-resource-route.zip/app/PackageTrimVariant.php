<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PackageTrimVariant extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'vehicle_manufacture_id',
        'vehicle_model_id',
        'created_by',
    ];
    public function manufacture()
    {
        return $this->belongsTo(VehicleManufacture::class, 'vehicle_manufacture_id', 'id');
    }
    public function model()
    {
        return $this->belongsTo(VehicleModel::class, 'vehicle_model_id', 'id');
    }
}
