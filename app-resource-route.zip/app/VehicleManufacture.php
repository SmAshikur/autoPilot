<?php

namespace App;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class VehicleManufacture extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'category',
        'country_id',
        'image',
        'created_by'
    ];
    public function country()
    {
        return $this->belongsTo(Country::class, 'country_id', 'id');
    }
}
